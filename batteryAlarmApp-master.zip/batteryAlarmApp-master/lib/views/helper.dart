import 'package:flutter/cupertino.dart';
import 'package:flutter_background_service/flutter_background_service.dart';

final ValueNotifier<bool> isBackgroundServiceRunningNotifier = ValueNotifier<bool>(false);


