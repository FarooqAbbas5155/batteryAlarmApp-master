package com.batterychargealarm.batteryalert.chargealarm.batteryinfo.battery_alarm

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
